<?php
session_start();
$code = $_SESSION['inst_code'];
$challan_number = $_GET['challan_number'];

$session_token = null;

include 'dbutils.php';
$conn = OpenCon();
if (isset($_SESSION['session_token'])) {
  $session_token = $_SESSION['session_token'];
}
$grantAccess = false;
$live_key = getKey($code, $conn); //db token
if ($live_key == $session_token) {
  $grantAccess = true;
}
if ($grantAccess) {

  $emis = getChallanIdentifier($challan_number, $conn);
  $chid = getChallanId($emis, $conn);
  $chamm = getChallanAmount($emis, $conn);


  if ($emis == NULL) {


    $sql = "UPDATE BankChallan SET BankChallan.isPaid='1' WHERE BankChallan.challan_id='" . $challan_number . "' AND BankChallan.isPaid='0';";

    if (mysqli_query($conn, $sql)) {
      setStudentLockByChallan($challan_number, $conn);
      header('location:../pages/challanUpdate.php?status=OK_S');
      exit();
    } else {
      mysqli_close($conn);
      echo "ERROR TYPE 2";
    }
  } else {

    if ($challan_number == $chid) {

      $sqld = "UPDATE BankChallan SET BankChallan.isPaid=1 WHERE BankChallan.challan_id='" . $challan_number . "' AND BankChallan.isPaid=0;";

      if (mysqli_query($conn, $sqld)) {

        $studentQuery = "SELECT Student.student_id, BankChallan.challan_id 
        FROM Student
        INNER JOIN StudentRegistration ON Student.student_id = StudentRegistration.student_student_id
        INNER JOIN BankChallan ON StudentRegistration.reg_challan_detail_challan_id = BankChallan.challan_id
        INNER JOIN RefFeeType ON RefFeeType.fee_type_id = BankChallan.challan_fee_type_fee_type_id
        WHERE Student.student_institute_inst_id = '$emis' AND BankChallan.isPaid = 0";

        $studentResult = $conn->query($studentQuery);

        if ($studentResult->num_rows > 0) {
          while ($row = $studentResult->fetch_assoc()) {
            $studentId = $row['student_id'];
            $challanId = $row['challan_id'];

            $updateQuery = "UPDATE BankChallan SET isPaid = 1 WHERE challan_id = '$challanId'";
            $conn->query($updateQuery);
          }
        }

        header('location:../pages/challanUpdate.php?status=OK_INSSTD_CHALLAN');
          
      } else {
        mysqli_close($conn);
        echo "ERROR TYPE 1";
      }
    }
  }

} else {
  echo "Unauthorize Access";
}
?>